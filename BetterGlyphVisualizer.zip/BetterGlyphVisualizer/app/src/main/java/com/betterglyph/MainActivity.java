package com.betterglyph;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.service.quicksettings.TileService;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private Button   btnToggle, btnVocal, btnBass;
    private TextView tvStatus, tvDeviceLabel;
    private View     statusDot;
    private Spinner  spinnerDevice;

    private boolean mIsVisualizing   = false;
    private int     mSelectedPreset  = AudioCaptureService.PRESET_VOCAL;
    private int     mSelectedDevice  = DeviceProfile.DEVICE_UNKNOWN;

    // Binder
    private AudioCaptureService mService = null;
    private boolean mBound = false;
    private int mPendingCode = 0;
    private Intent mPendingData = null;
    private boolean mHasToken = false;

    private final ServiceConnection mConn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            mService = ((AudioCaptureService.LocalBinder)b).getService();
            mBound   = true;
            if (mHasToken && mPendingData != null) {
                mService.setPreset(mSelectedPreset);
                mService.setDevice(mSelectedDevice);
                mService.startCapture(mPendingCode, mPendingData);
                mPendingCode=0; mPendingData=null; mHasToken=false;
            }
        }
        @Override public void onServiceDisconnected(ComponentName n) { mService=null; mBound=false; }
    };

    private MediaProjectionManager mProjMgr;

    private final ActivityResultLauncher<Intent> mProjLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    deliverToken(result.getResultCode(), result.getData());
                } else {
                    Toast.makeText(this,"Screen capture denied",Toast.LENGTH_SHORT).show();
                    updateUI(false); stopEverything();
                }
            });

    private final ActivityResultLauncher<String> mNotifLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), g -> requestProj());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToggle    = findViewById(R.id.btnToggle);
        btnVocal     = findViewById(R.id.btnVocal);
        btnBass      = findViewById(R.id.btnBass);
        tvStatus     = findViewById(R.id.tvStatus);
        tvDeviceLabel= findViewById(R.id.tvDeviceLabel);
        statusDot    = findViewById(R.id.statusDot);
        spinnerDevice= findViewById(R.id.spinnerDevice);

        mProjMgr = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        // Auto-detect device
        int detected = DeviceProfile.detectDevice();
        mSelectedDevice = (detected != DeviceProfile.DEVICE_UNKNOWN)
                ? detected : DeviceProfile.DEVICE_NP2;

        // Spinner options
        String[] deviceNames = {
            "Phone (1)","Phone (2)","Phone (2a) / 2a+","Phone (3a) / 3a Pro"
        };
        int[] deviceIds = {
            DeviceProfile.DEVICE_NP1, DeviceProfile.DEVICE_NP2,
            DeviceProfile.DEVICE_NP2A, DeviceProfile.DEVICE_NP3A
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, deviceNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDevice.setAdapter(adapter);

        // Select detected device in spinner
        for (int i=0;i<deviceIds.length;i++) {
            if (deviceIds[i]==mSelectedDevice) { spinnerDevice.setSelection(i); break; }
        }

        // Update label
        if (detected != DeviceProfile.DEVICE_UNKNOWN) {
            tvDeviceLabel.setText("Auto-detected: " + DeviceProfile.deviceName(detected));
        } else {
            tvDeviceLabel.setText("Device not detected — select manually");
        }

        spinnerDevice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                mSelectedDevice = deviceIds[pos];
                if (mIsVisualizing) { stopEverything(); updateUI(false);
                    Toast.makeText(MainActivity.this,"Device changed — tap Start",Toast.LENGTH_SHORT).show(); }
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        selectPreset(AudioCaptureService.PRESET_VOCAL);
        updateUI(false);

        btnVocal.setOnClickListener(v -> selectPreset(AudioCaptureService.PRESET_VOCAL));
        btnBass.setOnClickListener(v  -> selectPreset(AudioCaptureService.PRESET_BASS));
        btnToggle.setOnClickListener(v -> {
            if (mIsVisualizing) { stopEverything(); updateUI(false); }
            else { requestStart(); }
        });
    }

    @Override protected void onDestroy() {
        if (mBound) { unbindService(mConn); mBound=false; }
        super.onDestroy();
    }

    private void selectPreset(int preset) {
        mSelectedPreset = preset;
        btnVocal.setAlpha(preset==AudioCaptureService.PRESET_VOCAL?1f:0.45f);
        btnBass.setAlpha(preset==AudioCaptureService.PRESET_BASS?1f:0.45f);
        if (mIsVisualizing) { stopEverything(); updateUI(false);
            Toast.makeText(this,"Preset changed — tap Start",Toast.LENGTH_SHORT).show(); }
    }

    private void requestStart() {
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)
                !=PackageManager.PERMISSION_GRANTED) {
            mNotifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS); return;
        }
        requestProj();
    }

    private void requestProj() {
        mProjLauncher.launch(mProjMgr.createScreenCaptureIntent());
    }

    private void deliverToken(int code, Intent data) {
        Intent svc=new Intent(this,AudioCaptureService.class);
        ContextCompat.startForegroundService(this,svc);
        if (mBound&&mService!=null) {
            mService.setPreset(mSelectedPreset); mService.setDevice(mSelectedDevice);
            mService.startCapture(code,data);
        } else {
            mPendingCode=code; mPendingData=data; mHasToken=true;
            bindService(svc,mConn,Context.BIND_AUTO_CREATE);
        }
        updateUI(true);
    }

    private void stopEverything() {
        if (mBound&&mService!=null) mService.stopCapture();
        if (mBound) { unbindService(mConn); mBound=false; mService=null; }
        stopService(new Intent(this,AudioCaptureService.class));
    }

    private void updateUI(boolean active) {
        mIsVisualizing=active;
        TileService.requestListeningState(this,new ComponentName(this,VisualizerTileService.class));
        runOnUiThread(()->{
            btnToggle.setText(active?"STOP":"START");
            statusDot.setBackgroundResource(active?R.drawable.dot_active:R.drawable.dot_inactive);
            String preset=mSelectedPreset==AudioCaptureService.PRESET_VOCAL?"Vocal Heavy":"Bass Heavy";
            tvStatus.setText(active?preset+" — listening…":"Select preset and tap Start");
        });
    }
}
