package com.betterglyph;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.nothing.ketchum.Common;
import com.nothing.ketchum.GlyphException;
import com.nothing.ketchum.GlyphFrame;
import com.nothing.ketchum.GlyphManager;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AudioCaptureService extends Service {

    private static final String TAG        = "GlyphViz:Service";
    private static final String CHANNEL_ID = "glyph_viz_channel";
    private static final int    NOTIF_ID   = 1;

    public static final int PRESET_VOCAL = 0;
    public static final int PRESET_BASS  = 1;

    private int mPreset = PRESET_VOCAL;
    private int mDevice = DeviceProfile.DEVICE_NP2;

    public void setPreset(int preset) { mPreset = preset; }
    public void setDevice(int device) { mDevice = device; }

    private static volatile boolean sRunning = false;
    public  static boolean isRunning() { return sRunning; }

    // ── Audio constants ────────────────────────────────────────────────────
    private static final int   SR          = 44100;
    private static final int   V_HOP       = SR / 60;   // 735 — 60fps vocal
    private static final int   V_WIN       = 2048;
    private static final float V_HZ_BIN    = (float) SR / V_WIN;
    private static final float V_DECAY     = 0.94f;
    private static final float V_THRESHOLD = 0.13f;

    private static final int   B_FFT       = 4096;
    private static final int   B_HOP       = 512;
    private static final float B_HZ_BIN    = (float) SR / B_FFT;
    private static final float B_T_ON      = 2.4f;
    private static final float B_S_ON      = 1.7f;
    private static final float B_E1_THR    = 2.7f;

    // ── Vocal state ────────────────────────────────────────────────────────
    private float[] vDecayed, vPeak;

    // ── Bass state ─────────────────────────────────────────────────────────
    private float[] bTEnv, bTPeak, bSEnv, bSBase;
    private float bRmsTEnv=0, bRmsTPeak=0.0001f, bRmsSEnv=0, bRmsSBase=0.0001f;
    private int bD1Peak=0, bD1Hold=0;
    private static final int B_D1_HOLD = 6;

    // ── Shared ─────────────────────────────────────────────────────────────
    private int  mLastHash=-999;
    private long mLastSendMs=0;
    private static final long MIN_SEND_MS = 20;

    // ── Glyph ──────────────────────────────────────────────────────────────
    private GlyphManager mGM = null;
    private boolean mSessionOpen = false;
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    private final GlyphManager.Callback mGlyphCallback = new GlyphManager.Callback() {
        @Override
        public void onServiceConnected(ComponentName cn) {
            String dev = DeviceProfile.deviceCode(mDevice);
            switch (mDevice) {
                case DeviceProfile.DEVICE_NP1:  mGM.register(com.nothing.ketchum.Glyph.DEVICE_20111); break;
                case DeviceProfile.DEVICE_NP2:  mGM.register(com.nothing.ketchum.Glyph.DEVICE_22111); break;
                case DeviceProfile.DEVICE_NP2A: mGM.register(com.nothing.ketchum.Glyph.DEVICE_23111); break;
                case DeviceProfile.DEVICE_NP3A: mGM.register(com.nothing.ketchum.Glyph.DEVICE_24111); break;
                default:                         mGM.register(com.nothing.ketchum.Glyph.DEVICE_22111);
            }
            try { mGM.openSession(); mSessionOpen=true; Log.d(TAG,"Session open for "+dev); }
            catch (GlyphException e) { Log.e(TAG,"Session fail: "+e.getMessage()); }
        }
        @Override public void onServiceDisconnected(ComponentName cn) { mSessionOpen=false; }
    };

    public class LocalBinder extends Binder {
        public AudioCaptureService getService() { return AudioCaptureService.this; }
    }
    private final IBinder mBinder = new LocalBinder();
    @Override public IBinder onBind(Intent i) { return mBinder; }

    @Override
    public void onCreate() {
        super.onCreate();
        sRunning = true;
        mGM = GlyphManager.getInstance(getApplicationContext());
        mGM.init(mGlyphCallback);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification());
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        sRunning = false;
        stopCapture();
        if (mSessionOpen) try { mGM.closeSession(); } catch (GlyphException ignored) {}
        mGM.unInit();
        super.onDestroy();
    }

    private MediaProjection  mProjection;
    private AudioRecord      mAudioRecord;
    private ExecutorService  mExecutor;
    private volatile boolean mCapturing = false;

    public void startCapture(int resultCode, Intent data) {
        if (mCapturing) stopCapture();

        // Initialise state arrays based on device zones
        float[][] zones = DeviceProfile.getVocalZones(mDevice);
        vDecayed = new float[zones.length];
        vPeak    = new float[zones.length];
        for (int i = 0; i < zones.length; i++) vPeak[i] = 0.0001f;

        int numBands = getBassBands().length;
        bTEnv  = new float[numBands]; bTPeak = new float[numBands];
        bSEnv  = new float[numBands]; bSBase = new float[numBands];
        for (int i = 0; i < numBands; i++) { bTPeak[i]=0.0001f; bSBase[i]=0.0001f; }

        MediaProjectionManager pm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mProjection = pm.getMediaProjection(resultCode, data);
        if (mProjection == null) { Log.e(TAG,"Null projection"); return; }
        mProjection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopCapture(); stopSelf(); }
        }, mHandler);
        mExecutor = Executors.newSingleThreadExecutor();
        if (mPreset == PRESET_VOCAL) mExecutor.submit(this::captureVocal);
        else                         mExecutor.submit(this::captureBass);
    }

    public void stopCapture() {
        mCapturing = false;
        if (mAudioRecord != null) {
            try { mAudioRecord.stop(); } catch (Exception ignored) {}
            mAudioRecord.release(); mAudioRecord=null;
        }
        if (mProjection != null) { mProjection.stop(); mProjection=null; }
        if (mExecutor != null) { mExecutor.shutdownNow(); mExecutor=null; }
        mHandler.post(() -> { if (mGM!=null&&mSessionOpen) try { mGM.turnOff(); } catch (Exception ignored) {} });
    }

    private float[][] getBassBands() {
        switch (mDevice) {
            case DeviceProfile.DEVICE_NP1:  return DeviceProfile.BASS_NP1_BANDS;
            case DeviceProfile.DEVICE_NP2A: return DeviceProfile.BASS_NP2A_BANDS;
            case DeviceProfile.DEVICE_NP3A: return DeviceProfile.BASS_NP3A_BANDS;
            default:                         return DeviceProfile.BASS_NP2_BANDS;
        }
    }

    private AudioRecord buildRecord(int bufSize) {
        AudioPlaybackCaptureConfiguration cfg =
                new AudioPlaybackCaptureConfiguration.Builder(mProjection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build();
        int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        return new AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(Math.max(min, bufSize)).build();
    }

    // ══════════════════════════════════════════════════════════════════════
    // VOCAL HEAVY
    // ══════════════════════════════════════════════════════════════════════
    private void captureVocal() {
        mAudioRecord = buildRecord(V_WIN * 4);
        if (mAudioRecord.getState() != AudioRecord.STATE_INITIALIZED) { stopSelf(); return; }
        mAudioRecord.startRecording(); mCapturing=true;
        Log.d(TAG, "Vocal capture started, device="+mDevice);

        float[][] zones = DeviceProfile.getVocalZones(mDevice);
        int nz = zones.length;

        float[] hann = new float[V_WIN];
        for (int i=0;i<V_WIN;i++) hann[i]=0.5f*(1f-(float)Math.cos(2*Math.PI*i/(V_WIN-1)));

        int[] lo=new int[nz], hi=new int[nz];
        for (int z=0;z<nz;z++) {
            lo[z]=Math.max(1,Math.round(zones[z][0]/V_HZ_BIN));
            hi[z]=Math.min(V_WIN/2-1,Math.round(zones[z][1]/V_HZ_BIN));
        }

        float[] ring=new float[V_WIN]; int rPos=0,filled=0;
        short[] hop=new short[V_HOP];
        float[] re=new float[V_WIN],im=new float[V_WIN];

        while (mCapturing) {
            int read=mAudioRecord.read(hop,0,V_HOP); if(read<=0) continue;
            for (int i=0;i<read;i++){ring[rPos]=hop[i]/32768f;rPos=(rPos+1)%V_WIN;}
            filled=Math.min(filled+read,V_WIN); if(filled<V_WIN) continue;
            for (int i=0;i<V_WIN;i++){re[i]=ring[(rPos+i)%V_WIN]*hann[i];im[i]=0f;}
            fft(re,im,V_WIN);
            float[] peaks=new float[nz];
            for (int z=0;z<nz;z++){float p=0;for(int k=lo[z];k<=hi[z];k++){float m=(float)Math.sqrt(re[k]*re[k]+im[k]*im[k]);if(m>p)p=m;}peaks[z]=p;}
            final float[] fp=peaks.clone();
            mHandler.post(()->processVocal(fp,DeviceProfile.getVocalZones(mDevice)));
        }
    }

    private void processVocal(float[] rawPeaks, float[][] zones) {
        if (!mSessionOpen||mGM==null) return;
        long now=System.currentTimeMillis(); if(now-mLastSendMs<MIN_SEND_MS) return; mLastSendMs=now;
        int nz=zones.length;
        for (int z=0;z<nz;z++) {
            vDecayed[z]=Math.max(vDecayed[z],rawPeaks[z]);
            vDecayed[z]=V_DECAY*vDecayed[z]+(1f-V_DECAY)*rawPeaks[z];
            if(vDecayed[z]>vPeak[z]) vPeak[z]=vDecayed[z];
            vPeak[z]=Math.max(vPeak[z]*0.9999f,0.0001f);
        }
        float[] norm=new float[nz];
        for (int z=0;z<nz;z++){float n=vDecayed[z]/vPeak[z];norm[z]=n*n;}

        ArrayList<Integer> ch=new ArrayList<>();

        // NP2 special: E1 pct clamp + D1 cumulative bass fill
        if (mDevice==DeviceProfile.DEVICE_NP2) {
            for (int z=0;z<=23;z++) if(norm[z]>V_THRESHOLD) ch.add(z);
            float e1p=norm[24]*100f; if(e1p>V_THRESHOLD*100f&&e1p<70f) ch.add(24);
            float bassN=norm[25];
            for (int d=0;d<8;d++) if(bassN>Math.max((float)d/8f,V_THRESHOLD)) ch.add(25+d);
        } else {
            // All other devices: simple threshold per zone
            for (int z=0;z<nz;z++) if(norm[z]>V_THRESHOLD) ch.add((int)zones[z][2]);
        }

        sendGlyph(ch);
    }

    // ══════════════════════════════════════════════════════════════════════
    // BASS HEAVY
    // ══════════════════════════════════════════════════════════════════════
    private void captureBass() {
        mAudioRecord = buildRecord(B_FFT*2);
        if (mAudioRecord.getState()!=AudioRecord.STATE_INITIALIZED){stopSelf();return;}
        mAudioRecord.startRecording(); mCapturing=true;
        Log.d(TAG,"Bass capture started, device="+mDevice);

        float[][] bands=getBassBands(); int nb=bands.length;
        float[] hann=new float[B_FFT];
        for(int i=0;i<B_FFT;i++) hann[i]=0.5f*(1f-(float)Math.cos(2*Math.PI*i/(B_FFT-1)));
        int[] lo=new int[nb],hi=new int[nb];
        for(int b=0;b<nb;b++){lo[b]=Math.max(1,Math.round(bands[b][0]/B_HZ_BIN));hi[b]=Math.min(B_FFT/2-1,Math.round(bands[b][1]/B_HZ_BIN));}
        float[] ring=new float[B_FFT]; int rPos=0,filled=0;
        short[] hop=new short[B_HOP];
        float[] re=new float[B_FFT],im=new float[B_FFT];

        while (mCapturing) {
            int read=mAudioRecord.read(hop,0,B_HOP); if(read<=0) continue;
            for(int i=0;i<read;i++){ring[rPos]=hop[i]/32768f;rPos=(rPos+1)%B_FFT;}
            filled=Math.min(filled+read,B_FFT); if(filled<B_FFT) continue;
            for(int i=0;i<B_FFT;i++){re[i]=ring[(rPos+i)%B_FFT]*hann[i];im[i]=0f;}
            fft(re,im,B_FFT);
            float[] mag=new float[nb];
            for(int b=0;b<nb;b++){float sum=0;int cnt=Math.max(1,hi[b]-lo[b]+1);for(int k=lo[b];k<=hi[b];k++)sum+=re[k]*re[k]+im[k]*im[k];mag[b]=(float)Math.sqrt(sum/cnt);}
            float rms=0; for(float v:mag)rms+=v*v; rms=(float)Math.sqrt(rms/nb);
            final float[] fm=mag.clone(); final float fr=rms;
            mHandler.post(()->processBass(fm,fr));
        }
    }

    private void processBass(float[] mag, float rms) {
        if (!mSessionOpen||mGM==null) return;
        long now=System.currentTimeMillis(); if(now-mLastSendMs<MIN_SEND_MS) return; mLastSendMs=now;
        int nb=mag.length;
        for(int b=0;b<nb;b++){
            float m=mag[b];
            bTEnv[b]=m>bTEnv[b]?0.05f*bTEnv[b]+0.95f*m:0.72f*bTEnv[b]+0.28f*m;
            bTPeak[b]=Math.max(bTPeak[b]*0.9993f,bTEnv[b]*0.3f); bTPeak[b]=Math.max(bTPeak[b],0.0001f);
            bSEnv[b]=m>bSEnv[b]?0.20f*bSEnv[b]+0.80f*m:0.88f*bSEnv[b]+0.12f*m;
            bSBase[b]=bSEnv[b]>bSBase[b]?0.9985f*bSBase[b]+0.0015f*bSEnv[b]:0.9940f*bSBase[b]+0.0060f*bSEnv[b];
            bSBase[b]=Math.max(bSBase[b],0.0001f);
        }
        bRmsTEnv=rms>bRmsTEnv?0.05f*bRmsTEnv+0.95f*rms:0.72f*bRmsTEnv+0.28f*rms;
        bRmsTPeak=Math.max(bRmsTPeak*0.9993f,bRmsTEnv*0.3f); bRmsTPeak=Math.max(bRmsTPeak,0.0001f);
        bRmsSEnv=rms>bRmsSEnv?0.20f*bRmsSEnv+0.80f*rms:0.88f*bRmsSEnv+0.12f*rms;
        bRmsSBase=bRmsSEnv>bRmsSBase?0.9985f*bRmsSBase+0.0015f*bRmsSEnv:0.9940f*bRmsSBase+0.0060f*bRmsSEnv;
        bRmsSBase=Math.max(bRmsSBase,0.0001f);

        boolean[] active=new boolean[nb];
        for(int b=0;b<nb;b++){float tR=bTEnv[b]/bTPeak[b],sR=bSEnv[b]/bSBase[b];active[b]=tR>B_T_ON||sR>B_S_ON;}

        float vuT=bRmsTEnv/bRmsTPeak, vuS=bRmsSEnv/bRmsSBase;
        float vu=Math.max(vuT/3f,(vuS-0.8f)/1.2f); vu=Math.max(0f,Math.min(vu,1f));

        // D1 peak hold
        int d1Curr=Math.round(vu*8);
        if(d1Curr>=bD1Peak){bD1Peak=d1Curr;bD1Hold=B_D1_HOLD;}
        else if(bD1Hold>0){bD1Hold--;}
        else{bD1Peak=Math.max(bD1Peak-1,d1Curr);}

        boolean e1=false;
        for(int b=0;b<nb;b++) if(bTEnv[b]/bTPeak[b]>B_E1_THR){e1=true;break;}

        ArrayList<Integer> ch=new ArrayList<>();
        float[][] bands=getBassBands();

        // Check ring (bass-driven)
        float bassT=(bTEnv[0]/bTPeak[0]+bTEnv[1]/bTPeak[1]+bTEnv[Math.min(2,nb-1)]/bTPeak[Math.min(2,nb-1)])/3f;
        float bassS=(bSEnv[0]/bSBase[0]+bSEnv[1]/bSBase[1]+bSEnv[Math.min(2,nb-1)]/bSBase[Math.min(2,nb-1)])/3f;
        boolean bassRing=bassT>B_T_ON||bassS>B_S_ON;

        // Per-band LEDs
        for(int b=0;b<nb;b++) if(active[b]) ch.add((int)bands[b][2]);

        // Device-specific VU and ring
        switch (mDevice) {
            case DeviceProfile.DEVICE_NP1: {
                int c1Fill=Math.round(vu*16);
                // Use D1 bar (7-14) as VU meter
                for(int i=0;i<Math.min(bD1Peak,8);i++) ch.add(DeviceProfile.BASS_NP1_VU_INDICES[i]);
                if(e1) ch.add(DeviceProfile.BASS_NP1_E1);
                break;
            }
            case DeviceProfile.DEVICE_NP2: {
                if(bassRing) ch.add(DeviceProfile.BASS_NP2_RING);
                int c1Fill=Math.round(vu*16);
                for(int i=0;i<c1Fill;i++) ch.add(DeviceProfile.BASS_NP2_C1_INDICES[i]);
                for(int i=0;i<bD1Peak;i++) ch.add(DeviceProfile.BASS_NP2_D1_INDICES[i]);
                if(e1) ch.add(DeviceProfile.BASS_NP2_E1);
                break;
            }
            case DeviceProfile.DEVICE_NP2A: {
                if(bassRing) ch.add(DeviceProfile.BASS_NP2A_RING);
                int vuFill=Math.round(vu*16);
                for(int i=0;i<vuFill;i++) ch.add(DeviceProfile.BASS_NP2A_VU_INDICES[i]);
                break;
            }
            case DeviceProfile.DEVICE_NP3A: {
                if(bassRing) ch.add(DeviceProfile.BASS_NP3A_B1);
                int cFill=Math.round(vu*16);
                for(int i=0;i<cFill;i++) ch.add(DeviceProfile.BASS_NP3A_C_INDICES[i]);
                for(int i=0;i<bD1Peak;i++) ch.add(DeviceProfile.BASS_NP3A_A_INDICES[i]);
                break;
            }
        }

        sendGlyph(ch);
    }

    private void sendGlyph(ArrayList<Integer> ch) {
        int hash=ch.hashCode(); if(hash==mLastHash) return; mLastHash=hash;
        try {
            if(ch.isEmpty()){mGM.turnOff();return;}
            GlyphFrame.Builder b=mGM.getGlyphFrameBuilder();
            for(int c:ch) b.buildChannel(c);
            mGM.toggle(b.build());
        } catch(Exception e){Log.e(TAG,"Glyph: "+e.getMessage());}
    }

    private static void fft(float[] re, float[] im, int n) {
        int j=0;
        for(int i=1;i<n;i++){int bit=n>>1;for(;(j&bit)!=0;bit>>=1)j^=bit;j^=bit;if(i<j){float t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t;}}
        for(int len=2;len<=n;len<<=1){double ang=-2*Math.PI/len;float wr=(float)Math.cos(ang),wi=(float)Math.sin(ang);for(int i=0;i<n;i+=len){float cr=1f,ci=0f;for(int k=0;k<len/2;k++){float ur=re[i+k],ui=im[i+k],vr=re[i+k+len/2]*cr-im[i+k+len/2]*ci,vi=re[i+k+len/2]*ci+im[i+k+len/2]*cr;re[i+k]=ur+vr;im[i+k]=ui+vi;re[i+k+len/2]=ur-vr;im[i+k+len/2]=ui-vi;float nr=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=nr;}}}
    }

    private Notification buildNotification() {
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(nm.getNotificationChannel(CHANNEL_ID)==null){
            NotificationChannel c=new NotificationChannel(CHANNEL_ID,"Better Nothing Music Visualizer",NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(c);
        }
        PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        String mode=(mPreset==PRESET_VOCAL?"Vocal Heavy":"Bass Heavy")+" — "+DeviceProfile.deviceName(mDevice);
        return new NotificationCompat.Builder(this,CHANNEL_ID)
                .setContentTitle("Better Nothing Music Visualizer")
                .setContentText(mode)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi).setOngoing(true).setSilent(true).build();
    }
}
